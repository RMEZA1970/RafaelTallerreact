import React, { useState } from "react";
import MainTemplate from "./template/maintemplete";
import Login from "./page/login";

function App() {
  const [count, setCount] = useState(0);

  return (
    <>
      <div>
        <MainTemplate />
        <Login />
      </div>
    </>
  );
}

export default App;