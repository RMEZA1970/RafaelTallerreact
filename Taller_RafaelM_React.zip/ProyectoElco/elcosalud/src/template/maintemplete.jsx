import React from 'react';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { BrowserRouter, Route, Link, Routes } from 'react-router-dom';
import Visor from '../page/Visor';
import Servicios from '../page/Servicios';
import Badge from 'react-bootstrap/Badge';

const MainTemplate = () => {
  return (
    <>
      <BrowserRouter>
        <Navbar>
          <Container>
            <Navbar.Brand href="/">Clínicas y Hospitales Radiología</Navbar.Brand>
            <Navbar.Toggle aria-controls="navbarScroll" />
            <Navbar.Collapse id="navbarScroll">
              <Nav className="me-auto">
                <Nav.Link as={Link} to="/pag-inicio">
                  Inicio
                </Nav.Link>
                <Nav.Link as={Link} to="/pag-Empresa">
                  Empresa
                </Nav.Link>
                <Nav.Link as={Link} to="/pag-Servicios">
                  Servicios
                </Nav.Link>
                <Nav.Link as={Link} to="/pag-contacto">
                  Contacto
                </Nav.Link>
                <Nav.Link as={Link} to="/pag-Visor">
                  Visor
                </Nav.Link>
                <Badge bg="danger">Peligro</Badge>
              </Nav>
              <Form className="d-flex">
                <Form.Control
                  type="search"
                  placeholder="Buscar"
                  className="me-2"
                  aria-label="Buscar"
                />
                <Button variant="outline-success">Buscar</Button>
              </Form>
            </Navbar.Collapse>
          </Container>
        </Navbar>

        <Container>
          <Routes>
            <Route path="/pag-inicio" element={<h1>Página de inicio</h1>} />
            <Route path="/pag-Empresa" element={<h1>Página de Empresa</h1>} />
            <Route path="/pag-Servicios" element={<h1>Página de Servicios</h1>} />
            <Route path="/pag-Visor" element={<h1>Página de Visor</h1>} />
          </Routes>
        </Container>
      </BrowserRouter>
    </>
  );
};

export default MainTemplate;