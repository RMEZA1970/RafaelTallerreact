import React from 'react';  

Const Visor = ()=> {

return(
<div>
    <h1>Bienvenidos al Visor</h1>
   
</div>

);


};
export default Visor;