import React from 'react';  

Const Servicios = ()=> {

return(
<div>
    <h1>Portafolio de Servicios de Teleradiología de Elcosalud IPS</h1>
    <p>Nuestro equipo de radiólogos expertos ofrece informes de diagnóstico precisos y oportunos a través de la teleradiología. Utilizamos tecnología avanzada para visualizar y analizar imágenes médicas, brindando resultados confiables y de alta calidad.</p>

<h2>Nuestro Portafolio de Servicios de Teleradiología</h2>
<p>Diagnóstico Remoto de Imágenes: Contamos con radiólogos especializados que analizan y emiten informes precisos sobre imágenes médicas, sin importar la ubicación geográfica.
   Segunda Opinión Médica: Ofrecemos la posibilidad de obtener una segunda opinión radiológica de expertos en Teleradiología para validar y complementar diagnósticos previos.
   Interpretación de Estudios Radiológicos: Realizamos la interpretación de diversos estudios, como radiografías, tomografías computarizadas (CT), resonancias magnéticas (RM), mamografías, entre otros</p>

<p>Proporcionamos servicios de segunda opinión para ayudar a los médicos a confirmar diagnósticos y tomar decisiones informadas. Nuestros radiólogos especializados revisan los estudios previos y brindan una evaluación exhaustiva, asegurando una mayor precisión en el diagnóstico.</p>

<p>Estamos disponibles las 24 horas del día, los 7 días de la semana, para brindar servicios de radiología de urgencias. Nuestro equipo de expertos evalúa rápidamente las imágenes médicas para apoyar la toma de decisiones en situaciones críticas, lo que permite un tratamiento más ágil y eficiente.</p>

<p>Trabajamos en asociación con clínicas y centros de imágenes médicas para ofrecer servicios de teleradiología. Nuestra plataforma segura y eficiente permite la transmisión de imágenes y la comunicación fluida entre los proveedores de atención médica, mejorando la colaboración y la calidad de la atención.</p>

<p>Ofrecemos servicios de teleradiología, Radiología Convencional, Tomografía Computarizada, Resonancia Magnética, Ecografía, Mamografía, Contamos con expertos en el campo que utilizan estas tecnologías para proporcionar diagnósticos precisos y ayudar en el tratamiento de diversas condiciones médicas.</p>

</div>


);

};
export default Servicios;