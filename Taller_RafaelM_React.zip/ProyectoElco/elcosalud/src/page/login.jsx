import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import { Translation } from '../assets/translation';
import { login } from '../components/store/slices/Auth/AuthSlices';

const Login = () => {
  const dispatch = useDispatch();
  const { lang } = useSelector(state => state.setting);
  const [email, setEmail] = useState("");
  const [identificacion, setIdentificacion] = useState("");

  const crearSesion = (e) => {
    e.preventDefault();
    const token = '123456789';
    dispatch(login({ id: identificacion, correo: email, token: token }));
  }

  return (
    <Form onSubmit={crearSesion}>
      <Form.Group className="mb-3" controlId="formBasicIdentification">
        <Form.Label>{Translation[lang].placeholderId}</Form.Label>
        <Form.Control
          value={identificacion}
          onChange={(e) => setIdentificacion(e.target.value)}
          type="number"
          placeholder={Translation[lang].placeholderId}
          maxLength="10"
        />
        <Form.Text className="text-muted">
          Garantizamos que su identificación será tratada con confidencialidad y no será compartida con terceros.
        </Form.Text>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>{Translation[lang].placeholderEmail}</Form.Label>
        <Form.Control
          type="email"
          placeholder={Translation[lang].placeholderEmail}
          pattern=".+@.+"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <Form.Text className="text-muted">
          Garantizamos que su dirección de correo electrónico será tratada con confidencialidad y no será compartida con terceros.
        </Form.Text>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>{Translation[lang].placeholderPassword}</Form.Label>
        <Form.Control
          type="password"
          placeholder={Translation[lang].placeholderPassword}
          pattern="(?=.*[A-Z])(?=.*[!*\+]).+"
          required
        />
        <Form.Text className="text-muted">
          La contraseña debe contener al menos una letra mayúscula o uno de los siguientes caracteres: !, *, +.
        </Form.Text>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicCheckbox">
        <Form.Check type="checkbox" label={Translation[lang].labelRemember} />
      </Form.Group>

      <Button variant="primary" type="submit">
        {Translation[lang].buttonSubmit}
      </Button>
    </Form>
  );
}

export default Login;