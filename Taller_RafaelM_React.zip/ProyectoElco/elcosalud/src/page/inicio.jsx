import React from 'react';
import CarouselImagen from '../components/CarouselImagen';

const Inicio = () => {
  return (
    <div>
      <h1>Elcosalud IPS Innovación en Imágenes Médicas</h1>
      <p>
        Nuestro compromiso es brindarte precisión y calidad en cada diagnóstico,
        respaldado por la más avanzada tecnología y un equipo de expertos en imagenología.
        Confía en nosotros para cuidar tu salud y ofrecerte resultados confiables que marcan la diferencia
      </p>

      <h2>Nuestro Portafolio de Servicios de Teleradiología</h2>
      <p>
        Diagnóstico Remoto de Imágenes: Contamos con radiólogos especializados que analizan y emiten informes
        precisos sobre imágenes médicas, sin importar la ubicación geográfica. Segunda Opinión Médica: Ofrecemos
        la posibilidad de obtener una segunda opinión radiológica de expertos en Teleradiología para validar
        y complementar diagnósticos previos. Interpretación de Estudios Radiológicos: Realizamos la interpretación
        de diversos estudios, como radiografías, tomografías computarizadas (CT), resonancias magnéticas (RM),
        mamografías, entre otros
      </p>

      <h3>Expertos en Teleradiología: Soluciones Avanzadas para una Atención Médica Eficiente</h3>
      <p>
        Somos expertos en teleradiología y ofrecemos soluciones avanzadas para una atención médica eficiente.
        Nuestro objetivo es proporcionar servicios de diagnóstico por imágenes de alta calidad de manera remota,
        permitiendo a los profesionales de la salud acceder a informes radiológicos precisos y oportunos. Con
        tecnología de vanguardia y un equipo especializado, estamos comprometidos en brindar resultados confiables
        y contribuir a una atención médica ágil y eficiente
      </p>

      <CarouselImagen />
    </div>
  );
};

export default Inicio;
