import React from "react";
import Alert from "../components/Alertas";

const Contacto = () => {
  return (
    <div>
      <h1>Datos del paciente</h1>
      <Alert />
    </div>
  );
};

export default Contacto;