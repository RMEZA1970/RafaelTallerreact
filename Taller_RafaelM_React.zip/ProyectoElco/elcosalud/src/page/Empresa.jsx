import React from 'react';  

Const Empresa = ()=> {

return(
<div>
    <h1>Nuestra Historia</h1>
    <p>Durante una década de excelencia en servicios de teleradiología a nivel nacional, hemos demostrado nuestra solidez empresarial al brindar diagnósticos precisos y oportunos a través de tecnología de vanguardia. Nuestro compromiso con la seriedad y la calidad en cada informe radiológico ha establecido una reputación de confianza en el ámbito de la salud. A lo largo de estos 10 años, hemos sido un socio confiable para centros médicos y profesionales de la salud, ofreciendo servicios de teleradiología que han transformado la atención médica. Nuestra dedicación a la exactitud diagnóstica y a la eficiencia en la entrega de resultados ha sido reconocida a nivel nacional, posicionándonos como líderes en el campo de la teleradiología. Continuamos comprometidos en brindar servicios de calidad y contribuir al bienestar de los pacientes a través de nuestra experiencia en imágenes diagnósticas a distancia.</p>

</div>
);

};
export default Empresa;