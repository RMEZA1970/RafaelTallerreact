import React from 'react';
import Carousel from 'react-bootstrap/Carousel';
import ExampleCarouselImage from 'components/ExampleCarouselImage';

function CarouselImagen() {
  return (
    <Carousel>
      <Carousel.Item interval={1000}>
        <img
          className="d-block w-100"
          src="D:\Users\USER\Pictures\Saved Pictures\shutterstock_214504006.jpg"
          alt="First slide"
        />
        <Carousel.Caption>
          <h3>Teleradiología de Vanguardia</h3>
          <p>Acceso Remoto a Diagnósticos PrecisosEtiqueta de la primera diapositiva</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item interval={500}>
        <img
          className="d-block w-100"
          src="D:\Users\USER\Pictures\Saved Pictures\shutterstock_1942278202.jpg"
          alt="Second slide"
        />
        <Carousel.Caption>
          <h3>Confianza y Eficiencia en la Interpretación de Imágenes Médicas</h3>
          <p>Nuestros Servicios de Teleradiología"Etiqueta de la segunda diapositiva</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="D:\Users\USER\Pictures\Saved Pictures\vecteezy_light-doctor-screen-scanning-human-body_3168356.jpg"
          alt="Third slide"
        />
        <Carousel.Caption>
          <h3>Expertos en Teleradiología</h3>
          <p>
          Soluciones Avanzadas para una Atención Médica Eficiente
          </p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
}

export default CarouselImagen;